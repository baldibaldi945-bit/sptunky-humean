# Sprunki Retake Human — APK (Android)
By **@AxelzeroX23** — YouTube: https://youtube.com/@axelzerox023 — Instagram: https://www.instagram.com/axelzerox023

## طريقة الاستخدام
1. ارفع كل محتوى هذا المجلد إلى مستودع GitHub جديد (كل ملف أقل من 25 ميغا).
2. افتح تبويب **Actions** ← **Build APK** ← **Run workflow**.
3. بعد ما ينتهي، حمّل ملف الـ APK من **Artifacts**.

## ملاحظات
- المشروع (game.sb3) حجمه ~22 ميغا: تم تحويل wav/mp3 إلى ogg وضغط الرسومات.
- أوفلاين بالكامل: التطبيق بدون صلاحية إنترنت، والمشغّل داخل الـ APK (يتحمّل وقت البناء فقط).
- اللمس = ماوس، وزر SPACE على الشاشة بدل مفتاح المسافة.
- نص الوصف: عدّله من `app/src/main/assets/www/index.html` (قسم `#text`).
