#!/usr/bin/env bash
# ينسخ مشغّل سكراتش (TurboWarp scaffolding) داخل التطبيق ليعمل أوفلاين
set -euo pipefail
SRC=$(find node_modules/@turbowarp/scaffolding -name 'scaffolding-full.js' | head -n1)
[ -n "$SRC" ] || { echo "scaffolding-full.js not found"; ls -R node_modules/@turbowarp/scaffolding | head -50; exit 1; }
cp "$SRC" app/src/main/assets/www/scaffolding-full.js
echo "copied $SRC"
